
import java.util.*;

/**
 * 
 */
public class CompareTo implements StrategyComparateur {

    /**
     * Default constructor
     */
    public CompareTo() {
    }

    /**
     * @param string
     */
    public int calculDistance(String n1, String n2) {
        return(int) Math.abs(n1.compareTo((n2));
    }

}