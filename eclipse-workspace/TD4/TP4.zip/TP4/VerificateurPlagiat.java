
import java.util.*;

/**
 * 
 */
public class VerificateurPlagiat {
	private int treshold = 7;
	private StrategyComparateur maStrat;
	private ArrayList<StrategyComparateur> mesStrats = new ArrayList<StrategyComparateur>()
	
    /**
     * Default constructor
     */
    public VerificateurPlagiat(int treshold, StrategyComparateur maStrat, ArrayList mesStrats) {
    	this.treshold = treshold;
    	this.maStrat = maStrat;
    	this.mesStrats = mesStrats;
    }

    /**
     * 
     */


    /**
     * 
     */
    public boolean checkPlagiarism(String text ) {
        for()
        	if ( String.calculDistance < treshold) {
        		return true;
        	}
    }
    
    
    }

}