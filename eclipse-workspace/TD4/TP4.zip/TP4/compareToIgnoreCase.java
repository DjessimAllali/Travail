
import java.util.*;

/**
 * 
 */
public class compareToIgnoreCase implements StrategyComparateur {

    /**
     * Default constructor
     */
    public compareToIgnoreCase() {
    }

    /**
     * @return
     */
    public int calculDistance(String n1, String n2) {
        return (int) Math.abs(n1.compareToIgnoreCase(n2));
    }

 

}