
import java.util.*;

/**
 * 
 */
public interface StrategyComparateur {


    /**
     * @return
     */
    public int calculDistance(String n1, String n2);

}